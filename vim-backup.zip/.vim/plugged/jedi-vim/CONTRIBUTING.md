# We <3 pull requests!

 1. Fork the Repo on github.
 2. Add yourself to AUTHORS.txt
 3. Add a test if possible.
 4. Push to your fork and submit a pull request.

Please use PEP8 as a Python code style. For VIM, just try to style your
code similar to the jedi-vim code that is already there.

# Bug reports
Please include the output of `:version` and `:JediDebugInfo`.
